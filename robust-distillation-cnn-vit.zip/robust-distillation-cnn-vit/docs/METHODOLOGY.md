# Methodology

This document explains the math behind every loss in `src/distillation/`, why the models are built the way they are, and where this implementation intentionally simplifies its source papers.

## 1. Why a shared model interface matters

`ResNetCIFAR` (`src/models/cnn.py`) and `VisionTransformer` (`src/models/vit.py`) are unrelated architectures, but both implement the same contract:

```python
output = model(x, return_features=True)
output.logits           # (B, num_classes)
output.pooled_feature   # (B, feature_dim) -- a single embedding vector per sample
output.attention_maps   # list of (B, H, W) spatial attention maps
```

Every distillation loss is written against this contract, not against "CNN features" or "ViT features" specifically. That is what makes cross-architecture distillation (CNN → ViT, ViT → CNN) a config change rather than a new code path.

## 2. Vanilla response-based KD (Hinton et al., 2015)

Given student logits `z_s` and teacher logits `z_t`, and temperature `T`:

```
p_s = softmax(z_s / T)
p_t = softmax(z_t / T)
L_KD = T^2 * KL(p_t || p_s)
L_total = alpha * L_KD + (1 - alpha) * CE(z_s, y)
```

The `T^2` factor rescales the KD gradient to match the CE gradient's magnitude (Hinton et al.'s original observation) so `alpha` behaves consistently across different temperatures. Implemented in `soft_target_kd_loss` / `vanilla_kd_loss`.

## 3. Feature / hint distillation (FitNets, Romero et al., 2015)

FitNets matches intermediate representations, not just final logits. The original paper assumes student and teacher feature maps are the same shape (or resizes convolutionally). Here, student and teacher can be *different architectures entirely* — a ViT's CLS token and a ResNet's global-average-pooled feature don't even have the same dimensionality — so a learned linear **adapter** (`FeatureAdapter`) projects the student's pooled feature vector into the teacher's feature space before computing an MSE ("hint") loss:

```
h_s = Adapter(pooled_feature_s)              # student_dim -> teacher_dim
L_hint = MSE(h_s, stop_gradient(pooled_feature_t))
L_total = L_KD + beta_feature * L_hint
```

The adapter is trained jointly with the student (its parameters are added to the optimizer in `Trainer.__init__`); the teacher's feature is detached so gradients never flow into the frozen teacher.

## 4. Attention transfer, bridged across architectures (Zagoruyko & Komodakis, 2017)

The original Attention Transfer (AT) paper compares CNN-to-CNN spatial attention maps, computed as the sum of squared channel activations at each spatial location — "where in the image does this feature map respond strongly?" This project extends the same idea to ViTs by treating the **CLS token's attention over patch tokens**, reshaped into the patch grid, as a ViT's own spatial attention map (`VisionTransformer.cls_attention_to_grid`). Conceptually, both quantities answer the same question — "where is the network looking?" — despite coming from completely different mechanisms (activation magnitude vs. softmax attention weight).

Because a CNN's stages and a ViT's single CLS-attention map rarely have matching spatial resolutions, `attention_transfer_loss` bilinearly resizes the student's map to the teacher's resolution and L2-normalizes both (per sample, over all spatial positions) before comparing them with MSE — normalization matters because raw activation magnitudes and raw attention weights live on unrelated scales; only their *spatial distribution* is comparable.

```
L_AT = mean over matched (student_map, teacher_map) pairs of:
           MSE( normalize(resize(student_map)), normalize(teacher_map) )
L_total = L_KD + beta_attention * L_AT
```

When the two models expose a different number of attention maps (e.g. a 3-stage CNN vs. a 1-map ViT), maps are matched **from the end** — the deepest, most semantically meaningful maps are compared first (`combined_attention_transfer_loss`).

## 5. Adversarially robust distillation — ARD & RSLAD

Standard KD optimizes for matching the teacher on the *clean* data distribution; it says nothing about what happens under an adversarial perturbation. ARD (Goldblum et al., 2020) and RSLAD (Zi et al., 2021) both address this by generating the student's *training* examples adversarially, then using the teacher's **soft label** (rather than the ground-truth hard label) as the target — soft labels carry more information about the decision boundary's shape near the perturbed point, which empirically produces more robust students than hard-label adversarial training (Madry et al., 2018) alone.

Both methods, as implemented in `RobustDistillationLoss` (`src/distillation/robust.py`):

1. Compute the teacher's clean soft label: `p_t = softmax(teacher(x) / T)`.
2. Craft `x_adv` via PGD **against the student**, using an attack objective that maximizes `KL(softmax(student(x+δ)/T), p_t)` — i.e. the perturbation that pushes the student *furthest from the teacher's belief* is the one most worth training on.
3. Compute a robust loss `KL(softmax(student(x_adv)/T), target)`, where:
   - **ARD**: `target = p_t` (the teacher's *clean* soft label).
   - **RSLAD**: `target = softmax(teacher(x_adv)/T)` (the teacher's *own* response to the same adversarial input — treating the teacher as itself a source of "robust soft labels").
4. Add a natural-image term `KL(softmax(student(x)/T), p_t)` so clean accuracy doesn't collapse, and combine: `L_total = 0.5 * L_natural + 0.5 * L_robust`.

### Simplifications versus the original papers

This is a **pedagogical re-implementation** meant to make the core mechanism transparent and easy to extend, not a byte-for-byte reproduction of either paper's exact numbers. Specifically:

- Both papers assume (or separately train) an **already-robust teacher**; this project does not include a dedicated adversarial-training routine for the teacher itself — you can approximate one by pointing `configs/base.yaml`'s teacher-training run at an adversarially augmented dataset, but that is left as an extension (see the Roadmap in `README.md`).
- The 0.5 / 0.5 natural/robust weighting is fixed here rather than following either paper's exact schedule or ablated weighting.
- Both methods originally target ℓ∞-bounded PGD with specific step-count/epsilon schedules tuned per dataset; this project exposes those as plain config values (`adversarial.epsilon`, `adversarial.pgd_steps`, `adversarial.pgd_step_size`) for you to tune.

## 6. Why no input normalization?

`src/data/datasets.py` deliberately skips the usual CIFAR mean/std normalization, keeping every image in `[0, 1]`. Adversarial attacks (`src/attacks/adversarial.py`) define their epsilon-ball and clipping directly in pixel space; if the model's *input* were normalized by mean/std, `epsilon = 8/255` would silently mean something different than intended. BatchNorm (inside `ResNetCIFAR`) and LayerNorm (inside `VisionTransformer`) already provide internal activation normalization, so accuracy is essentially unaffected by skipping the input-level step.

## 7. Corruption robustness without a corrupted-dataset download

The official CIFAR-10-C / CIFAR-100-C benchmarks (Hendrycks & Dietterich, 2019) ship as pre-generated, multi-gigabyte tensor files. `src/data/corruptions.py` instead implements six corruption types (Gaussian noise, Gaussian blur, brightness shift, contrast shift, JPEG compression artifacts, random occlusion) at five severities each, applied on-the-fly to the existing test set. This trades a small amount of fidelity to the exact published corruption set for zero additional data-download requirements — swapping in the official tensors later (see Roadmap) is a drop-in change to `evaluate_corruptions` in `src/engine/evaluator.py`.
