"""CLI entry point for evaluating a trained checkpoint's robustness: clean
accuracy, adversarial accuracy (FGSM/PGD), and corruption accuracy.

Example
-------
    python scripts/evaluate.py --checkpoint results/vit_tiny_student/best.pt \
        --attack pgd --corruptions all
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch

from src.data.corruptions import CORRUPTIONS
from src.data.datasets import build_dataloaders, num_classes_for
from src.engine.evaluator import (
    evaluate_adversarial,
    evaluate_clean,
    evaluate_corruptions,
    summarize_robustness,
)
from src.models.factory import build_model


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate a checkpoint's clean/adversarial/corruption robustness."
    )
    parser.add_argument("--checkpoint", required=True, help="Path to a .pt checkpoint saved by scripts/train.py.")
    parser.add_argument("--attack", default="pgd", choices=["fgsm", "pgd"])
    parser.add_argument("--epsilon", type=float, default=8 / 255)
    parser.add_argument("--pgd-steps", type=int, default=20)
    parser.add_argument("--pgd-step-size", type=float, default=2 / 255)
    parser.add_argument(
        "--corruptions",
        default="none",
        help="'none', 'all', or a comma-separated subset, e.g. gaussian_noise,brightness",
    )
    parser.add_argument(
        "--output", default=None, help="Where to write the CSV report (default: alongside checkpoint)."
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    state = torch.load(args.checkpoint, map_location="cpu")
    cfg = state["config"]
    cfg["data"]["num_classes"] = num_classes_for(cfg["data"]["dataset"])

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg["model"]["name"], num_classes=cfg["data"]["num_classes"]).to(device)
    model.load_state_dict(state["model_state_dict"])
    model.eval()

    _, _, test_loader = build_dataloaders(cfg)

    print("Evaluating clean accuracy...")
    clean_acc = evaluate_clean(model, test_loader, device)
    print(f"  clean accuracy: {clean_acc:.2f}%")

    print(f"Evaluating {args.attack.upper()} adversarial accuracy (eps={args.epsilon:.4f})...")
    adv_acc = evaluate_adversarial(
        model,
        test_loader,
        device,
        attack=args.attack,
        epsilon=args.epsilon,
        pgd_steps=args.pgd_steps,
        pgd_step_size=args.pgd_step_size,
    )
    print(f"  {args.attack} accuracy: {adv_acc:.2f}%")

    corruption_results = {}
    if args.corruptions != "none":
        names = list(CORRUPTIONS.keys()) if args.corruptions == "all" else args.corruptions.split(",")
        print(f"Evaluating corruption robustness for: {names}")
        corruption_results = evaluate_corruptions(model, test_loader, device, corruption_names=names)

    summary = summarize_robustness(clean_acc, adv_acc, corruption_results)

    output_path = args.output or str(Path(args.checkpoint).parent / "robustness_report.csv")
    with open(output_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "value"])
        for k, v in summary.items():
            writer.writerow([k, f"{v:.4f}"])
        for name, sev_dict in corruption_results.items():
            for severity, acc in sev_dict.items():
                writer.writerow([f"corruption/{name}/severity_{severity}", f"{acc:.4f}"])

    print(f"\nSummary: {summary}")
    print(f"Full report written to {output_path}")


if __name__ == "__main__":
    main()
