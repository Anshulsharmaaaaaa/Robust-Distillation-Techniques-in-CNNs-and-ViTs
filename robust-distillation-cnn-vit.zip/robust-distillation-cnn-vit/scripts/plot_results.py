"""Turn one or more runs' robustness_report.csv / metrics.csv files into
comparison plots and a markdown results table (for pasting straight into
README.md's Results section).

Examples
--------
Plot training curves for a single run:
    python scripts/plot_results.py --curves results/resnet56_teacher/metrics.csv

Build a markdown comparison table across several robustness reports:
    python scripts/plot_results.py --markdown \
        results/vit_tiny_kd/robustness_report.csv \
        results/vit_tiny_at/robustness_report.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.utils.visualization import plot_training_curves


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Plot or tabulate training/robustness results.")
    parser.add_argument("--curves", default=None, help="Path to a metrics.csv to plot training curves for.")
    parser.add_argument("--save", default=None, help="Where to save the training-curves figure (PNG).")
    parser.add_argument(
        "--markdown",
        nargs="*",
        default=None,
        help="One or more robustness_report.csv paths to combine into a markdown table.",
    )
    return parser.parse_args()


def _read_report(path: str) -> Dict[str, str]:
    values: Dict[str, str] = {}
    with open(path, "r") as f:
        reader = csv.reader(f)
        next(reader)  # header row
        for row in reader:
            if not row:
                continue
            metric, value = row
            values[metric] = value
    return values


def build_markdown_table(report_paths: List[str]) -> str:
    header = "| Run | Clean Acc. | Adversarial Acc. | Mean Corruption Acc. |"
    separator = "|---|---|---|---|"
    rows = [header, separator]

    for path in report_paths:
        run_name = Path(path).parent.name
        values = _read_report(path)
        rows.append(
            f"| {run_name} | {values.get('clean_accuracy', '-')} "
            f"| {values.get('adversarial_accuracy', '-')} "
            f"| {values.get('mean_corruption_accuracy', '-')} |"
        )

    return "\n".join(rows)


def main() -> None:
    args = parse_args()

    if args.curves:
        plot_training_curves(args.curves, save_path=args.save)

    if args.markdown:
        table = build_markdown_table(args.markdown)
        print("\n" + table + "\n")


if __name__ == "__main__":
    main()
