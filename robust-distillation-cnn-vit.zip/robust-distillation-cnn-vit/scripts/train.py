"""CLI entry point for training a standalone teacher/student or running any
distillation strategy in src/distillation/.

Examples
--------
Train a CNN teacher from scratch:
    python scripts/train.py --config configs/base.yaml --model resnet56 --role teacher

Distill a ViT-Tiny student from a trained CNN teacher with vanilla KD:
    python scripts/train.py --config configs/kd_resnet_teacher_vit_student.yaml \
        --teacher-ckpt results/resnet56_teacher/best.pt
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Allow `python scripts/train.py` to import the `src` package without
# requiring `pip install -e .` first.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.data.datasets import build_dataloaders, num_classes_for
from src.engine.trainer import Trainer
from src.utils.config import load_config


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a model with optional distillation.")
    parser.add_argument("--config", required=True, help="Path to a YAML config (see configs/).")
    parser.add_argument("--model", default=None, help="Override model.name, e.g. resnet56 or vit_tiny.")
    parser.add_argument("--role", default=None, choices=["teacher", "student"], help="Override model.role.")
    parser.add_argument("--run-name", default=None, help="Override run_name / output subdirectory.")
    parser.add_argument("--teacher-ckpt", default=None, help="Override distill.teacher_checkpoint.")
    parser.add_argument("--epochs", type=int, default=None, help="Override optim.epochs.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = load_config(args.config)

    if args.model:
        cfg["model"]["name"] = args.model
    if args.role:
        cfg["model"]["role"] = args.role
    if args.run_name:
        cfg["run_name"] = args.run_name
    if args.teacher_ckpt:
        cfg.setdefault("distill", {})["teacher_checkpoint"] = args.teacher_ckpt
    if args.epochs:
        cfg["optim"]["epochs"] = args.epochs

    cfg["data"]["num_classes"] = num_classes_for(cfg["data"]["dataset"])

    train_loader, val_loader, _ = build_dataloaders(cfg)

    trainer = Trainer(cfg)
    trainer.fit(train_loader, val_loader)


if __name__ == "__main__":
    main()
