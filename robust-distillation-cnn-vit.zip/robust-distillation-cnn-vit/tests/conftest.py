"""Makes `src` importable when running `pytest tests/` from the repo root
without first requiring `pip install -e .`.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
