"""Shape and forward-pass sanity checks for the CNN and ViT model families.
These run on CPU with tiny random inputs -- no dataset required.
"""

import torch

from src.models.factory import build_model, count_parameters


def test_resnet_forward_shape():
    model = build_model("resnet20", num_classes=10)
    x = torch.randn(2, 3, 32, 32)
    logits = model(x)
    assert logits.shape == (2, 10)


def test_resnet_features_and_attention():
    model = build_model("resnet56", num_classes=10)
    x = torch.randn(2, 3, 32, 32)
    out = model(x, return_features=True)

    assert out.logits.shape == (2, 10)
    assert len(out.features) == 3
    assert len(out.attention_maps) == 3
    # A 32x32 input with two stride-2 stages leaves an 8x8 final feature map.
    assert out.attention_maps[-1].shape[-2:] == (8, 8)


def test_vit_forward_shape():
    model = build_model("vit_tiny", num_classes=10)
    x = torch.randn(2, 3, 32, 32)
    logits = model(x)
    assert logits.shape == (2, 10)


def test_vit_features_and_attention():
    model = build_model("vit_small", num_classes=10)
    x = torch.randn(2, 3, 32, 32)
    out = model(x, return_features=True)

    assert out.logits.shape == (2, 10)
    assert out.pooled_feature.shape == (2, model.feature_dim)
    assert len(out.attention_maps) == 1
    # patch_size=4 on a 32x32 image gives an 8x8 patch grid.
    assert out.attention_maps[0].shape[-2:] == (8, 8)


def test_cnn_student_is_smaller_than_cnn_teacher():
    student = build_model("resnet20", num_classes=10)
    teacher = build_model("resnet56", num_classes=10)
    assert count_parameters(student) < count_parameters(teacher)


def test_vit_student_is_smaller_than_vit_teacher():
    student = build_model("vit_tiny", num_classes=10)
    teacher = build_model("vit_small", num_classes=10)
    assert count_parameters(student) < count_parameters(teacher)
