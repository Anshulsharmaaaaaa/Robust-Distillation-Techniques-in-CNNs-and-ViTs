"""Checks that FGSM and PGD produce valid, epsilon-bounded, [0,1]-clipped
perturbations -- including when driven by a custom loss_fn (as used by the
robust distillation loss in src/distillation/robust.py) instead of a hard
label.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.attacks.adversarial import fgsm_attack, pgd_attack


class _DummyClassifier(nn.Module):
    """A tiny, cheap-to-differentiate stand-in for a real model -- these
    tests only care about the attack's numerical properties, not accuracy.
    """

    def __init__(self, num_classes: int = 10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(3, 8, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(8, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def test_fgsm_attack_respects_epsilon_and_valid_range():
    model = _DummyClassifier()
    x = torch.rand(4, 3, 32, 32)
    y = torch.randint(0, 10, (4,))
    epsilon = 8 / 255

    x_adv = fgsm_attack(model, x, y, epsilon)

    assert x_adv.shape == x.shape
    assert torch.all(x_adv >= 0.0) and torch.all(x_adv <= 1.0)
    assert torch.all((x_adv - x).abs() <= epsilon + 1e-6)


def test_pgd_attack_respects_epsilon_and_valid_range():
    model = _DummyClassifier()
    x = torch.rand(4, 3, 32, 32)
    y = torch.randint(0, 10, (4,))
    epsilon = 8 / 255

    x_adv = pgd_attack(model, x, y, epsilon, step_size=2 / 255, num_steps=5, random_start=True)

    assert x_adv.shape == x.shape
    assert torch.all(x_adv >= 0.0) and torch.all(x_adv <= 1.0)
    assert torch.all((x_adv - x).abs() <= epsilon + 1e-6)


def test_pgd_attack_with_custom_loss_fn_targets_a_soft_label():
    """Mirrors how RobustDistillationLoss drives PGD with a KL-divergence
    objective against a teacher's soft label instead of a hard label.
    """
    model = _DummyClassifier()
    x = torch.rand(4, 3, 32, 32)
    epsilon = 8 / 255
    target_soft_label = torch.softmax(torch.randn(4, 10), dim=1)

    def loss_fn(logits: torch.Tensor) -> torch.Tensor:
        log_probs = F.log_softmax(logits, dim=1)
        return F.kl_div(log_probs, target_soft_label, reduction="batchmean")

    x_adv = pgd_attack(model, x, y=None, epsilon=epsilon, step_size=2 / 255, num_steps=5, loss_fn=loss_fn)

    assert x_adv.shape == x.shape
    assert torch.all((x_adv - x).abs() <= epsilon + 1e-6)
