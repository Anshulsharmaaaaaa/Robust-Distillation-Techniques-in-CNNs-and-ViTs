"""Numerical sanity checks for every distillation loss: finiteness,
non-negativity where expected, and correct behavior of the cross-
architecture feature adapter and attention-map resizing.
"""

import pytest
import torch

from src.distillation.losses import (
    FeatureAdapter,
    attention_transfer_loss,
    combined_attention_transfer_loss,
    feature_distillation_loss,
    soft_target_kd_loss,
    vanilla_kd_loss,
)


def _random_logits(batch: int = 4, classes: int = 10) -> torch.Tensor:
    return torch.randn(batch, classes)


def test_soft_target_kd_loss_is_nonnegative_and_finite():
    loss = soft_target_kd_loss(_random_logits(), _random_logits(), temperature=4.0)
    assert torch.isfinite(loss)
    assert loss.item() >= 0.0


def test_soft_target_kd_loss_is_zero_for_identical_logits():
    logits = _random_logits()
    loss = soft_target_kd_loss(logits, logits, temperature=4.0)
    assert loss.item() == pytest.approx(0.0, abs=1e-5)


def test_vanilla_kd_loss_combines_kd_and_ce():
    targets = torch.randint(0, 10, (4,))
    loss, stats = vanilla_kd_loss(_random_logits(), _random_logits(), targets, alpha=0.5, temperature=4.0)
    assert torch.isfinite(loss)
    assert set(stats.keys()) == {"kd_loss", "ce_loss", "total_loss"}


def test_feature_distillation_loss_with_cross_dim_adapter():
    # Simulates a ViT-Tiny (96-d CLS token) student distilling from a
    # ResNet-56 (64-d pooled feature) teacher -- different feature dims.
    student_feature = torch.randn(4, 96)
    teacher_feature = torch.randn(4, 64)
    adapter = FeatureAdapter(student_dim=96, teacher_dim=64)

    targets = torch.randint(0, 10, (4,))
    loss, stats = feature_distillation_loss(
        student_feature, teacher_feature, adapter,
        _random_logits(), _random_logits(), targets,
        alpha=0.5, temperature=4.0, beta_feature=100.0,
    )
    assert torch.isfinite(loss)
    assert "hint_loss" in stats


def test_attention_transfer_loss_handles_different_resolutions():
    # CNN mid-stage map (16x16) vs. ViT patch-grid map (8x8).
    student_map = torch.rand(4, 16, 16)
    teacher_map = torch.rand(4, 8, 8)
    loss = attention_transfer_loss(student_map, teacher_map)
    assert torch.isfinite(loss)
    assert loss.item() >= 0.0


def test_attention_transfer_loss_is_near_zero_for_matching_maps():
    teacher_map = torch.rand(4, 8, 8)
    loss = attention_transfer_loss(teacher_map.clone(), teacher_map)
    assert loss.item() == pytest.approx(0.0, abs=1e-5)


def test_combined_attention_transfer_loss_matches_from_the_end():
    # A 3-stage CNN student vs. a ViT teacher exposing a single attention map
    # -- the loss should match the deepest/most-semantic maps only.
    student_maps = [torch.rand(4, 32, 32), torch.rand(4, 16, 16), torch.rand(4, 8, 8)]
    teacher_maps = [torch.rand(4, 8, 8)]

    targets = torch.randint(0, 10, (4,))
    loss, stats = combined_attention_transfer_loss(
        _random_logits(), _random_logits(), targets,
        student_maps, teacher_maps,
        alpha=0.5, temperature=4.0, beta_attention=1000.0,
    )
    assert torch.isfinite(loss)
    assert "attention_transfer_loss" in stats
