from setuptools import setup, find_packages

setup(
    name="robust-distillation-cnn-vit",
    version="0.1.0",
    description="Robust knowledge distillation across CNNs and Vision Transformers.",
    author="Anshul Sharma",
    url="https://github.com/Anshulsharmaaaaaa/robust-distillation-cnn-vit",
    packages=find_packages(include=["src", "src.*"]),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.1.0",
        "torchvision>=0.16.0",
        "pyyaml>=6.0",
        "numpy>=1.24",
        "tqdm>=4.66",
        "matplotlib>=3.7",
        "pandas>=2.0",
        "scikit-learn>=1.3",
    ],
    extras_require={"dev": ["pytest>=7.4"]},
)
