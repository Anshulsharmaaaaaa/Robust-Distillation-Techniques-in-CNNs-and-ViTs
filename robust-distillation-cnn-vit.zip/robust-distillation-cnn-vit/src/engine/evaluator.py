"""Robustness evaluation: clean accuracy, adversarial (FGSM/PGD) accuracy,
and corruption accuracy across every corruption type & severity in
src/data/corruptions.py. Used by scripts/evaluate.py.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import torch
import torch.nn as nn

from src.attacks.adversarial import fgsm_attack, pgd_attack
from src.data.corruptions import CORRUPTIONS, SEVERITIES, apply_corruption
from src.utils.metrics import AverageMeter, accuracy


@torch.no_grad()
def evaluate_clean(model: nn.Module, loader, device: torch.device) -> float:
    model.eval()
    meter = AverageMeter()
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        logits = model(x)
        acc1 = accuracy(logits, y, topk=(1,))[0]
        meter.update(acc1.item(), x.size(0))
    return meter.avg


def evaluate_adversarial(
    model: nn.Module,
    loader,
    device: torch.device,
    attack: str = "pgd",
    epsilon: float = 8 / 255,
    pgd_steps: int = 20,
    pgd_step_size: float = 2 / 255,
) -> float:
    model.eval()
    meter = AverageMeter()

    for x, y in loader:
        x, y = x.to(device), y.to(device)

        if attack == "fgsm":
            x_adv = fgsm_attack(model, x, y, epsilon)
        elif attack == "pgd":
            x_adv = pgd_attack(model, x, y, epsilon, pgd_step_size, pgd_steps, random_start=True)
        else:
            raise ValueError(f"Unknown attack '{attack}'. Use 'fgsm' or 'pgd'.")

        with torch.no_grad():
            logits = model(x_adv)
            acc1 = accuracy(logits, y, topk=(1,))[0]
        meter.update(acc1.item(), x.size(0))

    return meter.avg


@torch.no_grad()
def evaluate_corruptions(
    model: nn.Module, loader, device: torch.device, corruption_names: Optional[List[str]] = None
) -> Dict[str, Dict[int, float]]:
    """Returns {corruption_name: {severity: accuracy}} for every requested
    corruption type (defaults to every corruption registered in
    src/data/corruptions.py).
    """
    model.eval()
    names = corruption_names or list(CORRUPTIONS.keys())
    results: Dict[str, Dict[int, float]] = {name: {} for name in names}

    for name in names:
        for severity in SEVERITIES:
            meter = AverageMeter()
            for x, y in loader:
                x, y = x.to(device), y.to(device)
                x_corrupted = apply_corruption(x, name, severity)
                logits = model(x_corrupted)
                acc1 = accuracy(logits, y, topk=(1,))[0]
                meter.update(acc1.item(), x.size(0))
            results[name][severity] = meter.avg

    return results


def summarize_robustness(
    clean_acc: float, adv_acc: float, corruption_results: Dict[str, Dict[int, float]]
) -> Dict[str, float]:
    """Flattens a full robustness sweep into the headline numbers used for
    the README results table / robustness_report.csv.
    """
    all_corruption_accs = [acc for sev_dict in corruption_results.values() for acc in sev_dict.values()]
    mean_corruption_acc = (
        sum(all_corruption_accs) / len(all_corruption_accs) if all_corruption_accs else float("nan")
    )

    return {
        "clean_accuracy": clean_acc,
        "adversarial_accuracy": adv_acc,
        "mean_corruption_accuracy": mean_corruption_acc,
        "robustness_gap_adversarial": clean_acc - adv_acc,
        "robustness_gap_corruption": clean_acc - mean_corruption_acc,
    }
