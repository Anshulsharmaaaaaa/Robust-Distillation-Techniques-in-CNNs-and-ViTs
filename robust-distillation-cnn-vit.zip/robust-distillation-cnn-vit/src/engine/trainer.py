"""Generic training loop supporting both standalone (teacher) training and
every distillation strategy in src/distillation/, selected purely by config.
See scripts/train.py for the CLI entry point that builds a config and calls
this class.
"""

from __future__ import annotations

import os
import time
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import CosineAnnealingLR, StepLR

from src.distillation.losses import (
    FeatureAdapter,
    combined_attention_transfer_loss,
    feature_distillation_loss,
    vanilla_kd_loss,
)
from src.distillation.robust import RobustDistillationLoss
from src.models.factory import build_model, count_parameters
from src.utils.logger import RunLogger
from src.utils.metrics import AverageMeter, accuracy
from src.utils.seed import set_seed


class Trainer:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        set_seed(cfg.get("seed", 42))

        requested_device = cfg.get("device", "cuda")
        self.device = torch.device(requested_device if torch.cuda.is_available() else "cpu")

        self.run_dir = os.path.join(cfg["output_dir"], cfg["run_name"])
        os.makedirs(self.run_dir, exist_ok=True)
        self.logger = RunLogger(self.run_dir, cfg.get("log", {}).get("log_every_n_steps", 50))

        num_classes = cfg["data"]["num_classes"]
        self.student = build_model(cfg["model"]["name"], num_classes=num_classes).to(self.device)

        self.distill_cfg = cfg.get("distill", {})
        self.distill_enabled = self.distill_cfg.get("enabled", False)

        self.teacher: Optional[nn.Module] = None
        self.feature_adapter: Optional[FeatureAdapter] = None
        self.robust_loss_fn: Optional[RobustDistillationLoss] = None

        trainable_params = list(self.student.parameters())

        if self.distill_enabled:
            teacher_name = self.distill_cfg["teacher_name"]
            self.teacher = build_model(teacher_name, num_classes=num_classes).to(self.device)

            ckpt_path = self.distill_cfg["teacher_checkpoint"]
            state = torch.load(ckpt_path, map_location=self.device)
            self.teacher.load_state_dict(state["model_state_dict"])
            self.teacher.eval()
            for p in self.teacher.parameters():
                p.requires_grad_(False)

            method = self.distill_cfg["method"]

            if method == "feature":
                self.feature_adapter = FeatureAdapter(
                    student_dim=self.student.feature_dim, teacher_dim=self.teacher.feature_dim
                ).to(self.device)
                trainable_params += list(self.feature_adapter.parameters())

            if method == "robust_adversarial":
                adv_cfg = cfg["adversarial"]
                self.robust_loss_fn = RobustDistillationLoss(
                    teacher=self.teacher,
                    epsilon=adv_cfg["epsilon"],
                    pgd_steps=adv_cfg["pgd_steps"],
                    pgd_step_size=adv_cfg["pgd_step_size"],
                    temperature=self.distill_cfg.get("temperature", 1.0),
                    method=adv_cfg.get("method", "rslad"),
                    random_start=adv_cfg.get("random_start", True),
                )

        optim_cfg = cfg["optim"]
        if optim_cfg["optimizer"] == "sgd":
            self.optimizer = torch.optim.SGD(
                trainable_params,
                lr=optim_cfg["lr"],
                momentum=optim_cfg.get("momentum", 0.9),
                weight_decay=optim_cfg.get("weight_decay", 5e-4),
                nesterov=True,
            )
        else:
            self.optimizer = torch.optim.AdamW(
                trainable_params, lr=optim_cfg["lr"], weight_decay=optim_cfg.get("weight_decay", 0.05)
            )

        if optim_cfg.get("scheduler") == "cosine":
            self.scheduler = CosineAnnealingLR(self.optimizer, T_max=optim_cfg["epochs"])
        else:
            self.scheduler = StepLR(self.optimizer, step_size=max(1, optim_cfg["epochs"] // 3), gamma=0.1)

        self.epochs = optim_cfg["epochs"]
        self.label_smoothing = optim_cfg.get("label_smoothing", 0.0)
        self.best_val_acc = 0.0

        distill_desc = "off" if not self.distill_enabled else self.distill_cfg["method"]
        print(
            f"[Trainer] student={cfg['model']['name']} "
            f"({count_parameters(self.student) / 1e6:.2f}M params), "
            f"distill={distill_desc}, device={self.device}"
        )

    def _compute_loss(self, x: torch.Tensor, y: torch.Tensor):
        if not self.distill_enabled:
            logits = self.student(x)
            loss = F.cross_entropy(logits, y, label_smoothing=self.label_smoothing)
            return loss, {"ce_loss": loss.item()}, logits

        method = self.distill_cfg["method"]

        if method == "robust_adversarial":
            loss, stats = self.robust_loss_fn(self.student, x, y)
            with torch.no_grad():
                logits = self.student(x)
            return loss, stats, logits

        need_features = method in {"feature", "attention_transfer"}
        student_out = self.student(x, return_features=True) if need_features else None
        student_logits = student_out.logits if student_out is not None else self.student(x)

        with torch.no_grad():
            teacher_out = self.teacher(x, return_features=True) if need_features else None
            teacher_logits = teacher_out.logits if teacher_out is not None else self.teacher(x)

        alpha = self.distill_cfg.get("alpha", 0.5)
        temperature = self.distill_cfg.get("temperature", 4.0)

        if method == "vanilla_kd":
            loss, stats = vanilla_kd_loss(
                student_logits, teacher_logits, y, alpha, temperature, self.label_smoothing
            )
        elif method == "feature":
            loss, stats = feature_distillation_loss(
                student_out.pooled_feature,
                teacher_out.pooled_feature,
                self.feature_adapter,
                student_logits,
                teacher_logits,
                y,
                alpha,
                temperature,
                self.distill_cfg.get("beta_feature", 100.0),
            )
        elif method == "attention_transfer":
            loss, stats = combined_attention_transfer_loss(
                student_logits,
                teacher_logits,
                y,
                student_out.attention_maps,
                teacher_out.attention_maps,
                alpha,
                temperature,
                self.distill_cfg.get("beta_attention", 1000.0),
            )
        else:
            raise ValueError(f"Unknown distillation method '{method}'")

        return loss, stats, student_logits

    def train_one_epoch(self, loader, epoch: int) -> None:
        self.student.train()
        loss_meter, acc_meter = AverageMeter(), AverageMeter()
        start = time.time()

        for step, (x, y) in enumerate(loader):
            x, y = x.to(self.device, non_blocking=True), y.to(self.device, non_blocking=True)

            self.optimizer.zero_grad(set_to_none=True)
            loss, stats, logits = self._compute_loss(x, y)
            loss.backward()
            self.optimizer.step()

            acc1 = accuracy(logits, y, topk=(1,))[0]
            loss_meter.update(loss.item(), x.size(0))
            acc_meter.update(acc1.item(), x.size(0))

            if step % self.logger.log_every_n_steps == 0:
                self.logger.log_step(epoch, step, len(loader), stats, acc1.item())

        self.scheduler.step()
        elapsed = time.time() - start
        self.logger.log_epoch(epoch, "train", loss_meter.avg, acc_meter.avg, elapsed)

    @torch.no_grad()
    def evaluate(self, loader, split: str = "val") -> float:
        self.student.eval()
        acc_meter = AverageMeter()
        for x, y in loader:
            x, y = x.to(self.device), y.to(self.device)
            logits = self.student(x)
            acc1 = accuracy(logits, y, topk=(1,))[0]
            acc_meter.update(acc1.item(), x.size(0))
        self.logger.log_epoch(-1, split, None, acc_meter.avg, None)
        return acc_meter.avg

    def save_checkpoint(self, name: str) -> None:
        path = os.path.join(self.run_dir, f"{name}.pt")
        torch.save({"model_state_dict": self.student.state_dict(), "config": self.cfg}, path)

    def fit(self, train_loader, val_loader) -> None:
        for epoch in range(1, self.epochs + 1):
            self.train_one_epoch(train_loader, epoch)
            val_acc = self.evaluate(val_loader, split="val")

            if val_acc > self.best_val_acc:
                self.best_val_acc = val_acc
                self.save_checkpoint("best")

            if not self.cfg.get("log", {}).get("save_best_only", False):
                self.save_checkpoint("last")

        print(f"[Trainer] training complete. best val acc = {self.best_val_acc:.2f}%")
