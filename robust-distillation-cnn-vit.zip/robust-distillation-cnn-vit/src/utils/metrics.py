"""Standard training metrics: top-k accuracy and a running-average meter."""

from __future__ import annotations

from typing import List, Tuple

import torch


class AverageMeter:
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.sum = 0.0
        self.count = 0

    def update(self, value: float, n: int = 1) -> None:
        self.sum += value * n
        self.count += n

    @property
    def avg(self) -> float:
        return self.sum / self.count if self.count > 0 else 0.0


@torch.no_grad()
def accuracy(logits: torch.Tensor, targets: torch.Tensor, topk: Tuple[int, ...] = (1,)) -> List[torch.Tensor]:
    """Returns top-k accuracy (as a percentage) for each k in `topk`."""
    max_k = max(topk)
    batch_size = targets.size(0)

    _, pred = logits.topk(max_k, dim=1, largest=True, sorted=True)
    pred = pred.t()
    correct = pred.eq(targets.view(1, -1).expand_as(pred))

    results = []
    for k in topk:
        correct_k = correct[:k].reshape(-1).float().sum(0)
        results.append(correct_k * (100.0 / batch_size))
    return results
