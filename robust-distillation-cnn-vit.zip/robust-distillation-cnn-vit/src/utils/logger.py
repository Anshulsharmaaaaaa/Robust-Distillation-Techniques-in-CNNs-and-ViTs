"""Lightweight run logger: prints to console and appends every epoch's
metrics to a CSV under the run directory, so scripts/plot_results.py has
something to read without needing TensorBoard or an external service.
"""

from __future__ import annotations

import csv
import os
from typing import Dict, Optional


class RunLogger:
    def __init__(self, run_dir: str, log_every_n_steps: int = 50):
        self.run_dir = run_dir
        self.log_every_n_steps = log_every_n_steps
        self.csv_path = os.path.join(run_dir, "metrics.csv")
        self._csv_initialized = os.path.exists(self.csv_path)

    def log_step(self, epoch: int, step: int, total_steps: int, stats: Dict[str, float], acc1: float) -> None:
        stats_str = " ".join(f"{k}={v:.4f}" for k, v in stats.items())
        print(f"[epoch {epoch:03d} | step {step:04d}/{total_steps}] {stats_str} acc@1={acc1:.2f}%")

    def log_epoch(self, epoch: int, split: str, loss: Optional[float], acc: float, elapsed: Optional[float]) -> None:
        loss_str = f"{loss:.4f}" if loss is not None else "-"
        time_str = f"{elapsed:.1f}s" if elapsed is not None else "-"
        print(f"== epoch {epoch:03d} [{split}] loss={loss_str} acc@1={acc:.2f}% time={time_str} ==")

        row = {"epoch": epoch, "split": split, "loss": loss, "acc1": acc}
        write_header = not self._csv_initialized
        with open(self.csv_path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(row.keys()))
            if write_header:
                writer.writeheader()
                self._csv_initialized = True
            writer.writerow(row)
