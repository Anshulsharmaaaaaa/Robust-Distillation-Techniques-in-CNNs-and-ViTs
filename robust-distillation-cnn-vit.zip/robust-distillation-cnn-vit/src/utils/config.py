"""YAML config loading with a simple single-level `extends:` mechanism, so
an experiment config only needs to state what differs from configs/base.yaml
(see any file under configs/ for an example).
"""

from __future__ import annotations

import copy
import os
from typing import Any, Dict

import yaml


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if key == "extends":
            continue
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config(path: str) -> Dict[str, Any]:
    """Load a YAML config, recursively resolving `extends: other.yaml`
    (path relative to the file that declares it) before applying this
    file's own keys on top.
    """
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)

    if "extends" in cfg:
        base_path = os.path.join(os.path.dirname(path), cfg["extends"])
        base_cfg = load_config(base_path)
        cfg = _deep_merge(base_cfg, cfg)

    return cfg
