"""Plotting helpers: training curves from a run's metrics.csv, and side-by-
side attention-map comparisons -- useful for sanity-checking that attention
transfer is actually pulling the student's spatial focus toward the
teacher's.
"""

from __future__ import annotations

from typing import Optional

import matplotlib.pyplot as plt
import pandas as pd
import torch


def plot_training_curves(csv_path: str, save_path: Optional[str] = None) -> None:
    df = pd.read_csv(csv_path)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    for split in df["split"].unique():
        subset = df[(df["split"] == split) & (df["epoch"] >= 0)]
        if len(subset) == 0:
            continue
        axes[0].plot(subset["epoch"], subset["acc1"], label=split)
        if subset["loss"].notna().any():
            axes[1].plot(subset["epoch"], subset["loss"], label=split)

    axes[0].set_title("Top-1 Accuracy")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy (%)")
    axes[0].legend()

    axes[1].set_title("Loss")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()

    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
    else:
        plt.show()


def plot_attention_comparison(
    image: torch.Tensor,
    student_attention_map: torch.Tensor,
    teacher_attention_map: torch.Tensor,
    save_path: Optional[str] = None,
) -> None:
    """Side-by-side visualization of one image and its student/teacher
    spatial attention maps (each a single (H, W) tensor, e.g. taken from
    `ResNetCIFAROutput.attention_maps[-1][0]` or
    `ViTOutput.attention_maps[-1][0]`).
    """
    fig, axes = plt.subplots(1, 3, figsize=(9, 3))

    axes[0].imshow(image.permute(1, 2, 0).clamp(0, 1).cpu().numpy())
    axes[0].set_title("Input")

    axes[1].imshow(student_attention_map.detach().cpu().numpy(), cmap="viridis")
    axes[1].set_title("Student Attention")

    axes[2].imshow(teacher_attention_map.detach().cpu().numpy(), cmap="viridis")
    axes[2].set_title("Teacher Attention")

    for ax in axes:
        ax.axis("off")

    fig.tight_layout()
    if save_path:
        fig.savefig(save_path, dpi=150)
    else:
        plt.show()
