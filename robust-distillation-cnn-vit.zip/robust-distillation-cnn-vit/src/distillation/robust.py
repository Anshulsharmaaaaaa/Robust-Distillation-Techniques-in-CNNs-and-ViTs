"""Adversarially robust distillation: ARD (Goldblum et al., 2020) and RSLAD
(Zi et al., 2021) -- pedagogical re-implementations that capture the core
idea of each method: adversarial examples generated against the STUDENT,
guided by divergence from the teacher's soft label rather than the hard
label alone, then matched back to a soft target during training.

Simplifications versus the original papers (also noted in
docs/METHODOLOGY.md): both methods here assume a teacher that is already
reasonably robust (its own training is out of scope for this module -- see
scripts/train.py's baseline "teacher" mode, which can itself be pointed at
adversarial training if desired), and both use a single fixed alpha=0.5
split between the natural and robust terms rather than the schedules used
in the original papers.
"""

from __future__ import annotations

from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

from src.attacks.adversarial import pgd_attack
from src.distillation.losses import soft_target_kd_loss


class RobustDistillationLoss:
    """Adversarially robust, soft-label-guided distillation.

    Args:
        teacher: frozen teacher model (already trained, `eval()` and
            `requires_grad_(False)`'d by the caller).
        epsilon, pgd_steps, pgd_step_size, random_start: PGD attack budget
            used to craft the student's adversarial training examples.
        temperature: softmax temperature for every KL term.
        method: "ard" matches the teacher's CLEAN soft label on the
            adversarial input; "rslad" matches the teacher's soft label
            evaluated on that SAME adversarial input (i.e. the teacher's own
            response to the attack).
    """

    def __init__(
        self,
        teacher: nn.Module,
        epsilon: float,
        pgd_steps: int,
        pgd_step_size: float,
        temperature: float = 1.0,
        method: str = "rslad",
        random_start: bool = True,
    ):
        assert method in {"ard", "rslad"}, f"unknown robust distillation method '{method}'"
        self.teacher = teacher
        self.epsilon = epsilon
        self.pgd_steps = pgd_steps
        self.pgd_step_size = pgd_step_size
        self.temperature = temperature
        self.method = method
        self.random_start = random_start

    def _attack_loss_fn(self, teacher_soft_clean: torch.Tensor):
        """Attack objective: maximize the student's divergence from the
        teacher's clean soft label (the direction where the student is
        least teacher-like is the direction most worth training on).
        """

        def loss_fn(student_logits: torch.Tensor) -> torch.Tensor:
            student_log_probs = F.log_softmax(student_logits / self.temperature, dim=1)
            return F.kl_div(student_log_probs, teacher_soft_clean, reduction="batchmean")

        return loss_fn

    def __call__(self, student: nn.Module, x: torch.Tensor, y: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, float]]:
        # Teacher is frozen; only ever used under torch.no_grad().
        with torch.no_grad():
            teacher_logits_clean = self.teacher(x)
            teacher_soft_clean = F.softmax(teacher_logits_clean / self.temperature, dim=1)

        # Craft the adversarial example against the CURRENT student weights.
        # Attack-time forward/backward passes should not behave stochastically,
        # so the caller is expected to have the student in eval() mode only
        # for BN/dropout purposes during this call if desired; by default we
        # leave training-mode behavior to the caller's trainer loop.
        x_adv = pgd_attack(
            model=student,
            x=x,
            y=y,
            epsilon=self.epsilon,
            step_size=self.pgd_step_size,
            num_steps=self.pgd_steps,
            random_start=self.random_start,
            loss_fn=self._attack_loss_fn(teacher_soft_clean),
        )

        student_logits_adv = student(x_adv)

        if self.method == "ard":
            target = teacher_soft_clean
        else:  # rslad
            with torch.no_grad():
                teacher_logits_adv = self.teacher(x_adv)
                target = F.softmax(teacher_logits_adv / self.temperature, dim=1)

        student_log_probs_adv = F.log_softmax(student_logits_adv / self.temperature, dim=1)
        robust_loss = F.kl_div(student_log_probs_adv, target, reduction="batchmean") * (self.temperature ** 2)

        # Natural (clean-input) term keeps clean accuracy from collapsing --
        # both methods still care about un-attacked performance.
        student_logits_clean = student(x)
        natural_loss = soft_target_kd_loss(student_logits_clean, teacher_logits_clean, self.temperature)

        total_loss = 0.5 * natural_loss + 0.5 * robust_loss
        stats = {
            "natural_kd_loss": natural_loss.item(),
            "robust_kd_loss": robust_loss.item(),
            "total_loss": total_loss.item(),
        }
        return total_loss, stats
