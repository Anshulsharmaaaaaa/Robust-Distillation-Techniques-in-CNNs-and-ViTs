"""Distillation losses: vanilla response-based KD, feature/hint distillation
with a learned cross-architecture adapter, and attention transfer bridged
between CNN spatial attention maps and ViT CLS-attention grids.

Every loss function returns `(total_loss, stats_dict)` so the trainer can
log every component (KD term, hint term, attention term, ...) without
needing to know which method produced them -- see src/engine/trainer.py.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def soft_target_kd_loss(student_logits: torch.Tensor, teacher_logits: torch.Tensor, temperature: float) -> torch.Tensor:
    """T^2 * KL(softmax(teacher/T) || softmax(student/T)) -- Hinton et al., 2015."""
    student_log_probs = F.log_softmax(student_logits / temperature, dim=1)
    teacher_probs = F.softmax(teacher_logits / temperature, dim=1)
    return F.kl_div(student_log_probs, teacher_probs, reduction="batchmean") * (temperature ** 2)


def vanilla_kd_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    targets: torch.Tensor,
    alpha: float,
    temperature: float,
    label_smoothing: float = 0.0,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """alpha * KD(student, teacher) + (1 - alpha) * CE(student, targets)."""
    kd = soft_target_kd_loss(student_logits, teacher_logits, temperature)
    ce = F.cross_entropy(student_logits, targets, label_smoothing=label_smoothing)
    total = alpha * kd + (1 - alpha) * ce
    return total, {"kd_loss": kd.item(), "ce_loss": ce.item(), "total_loss": total.item()}


class FeatureAdapter(nn.Module):
    """Projects a student's pooled feature vector into the teacher's feature
    space, so hint/feature distillation works even across architectures
    (e.g. a 96-d ViT-Tiny CLS token vs. a 64-d ResNet-56 pooled feature). A
    single linear layer, as in FitNets' regressor (Romero et al., 2015).

    This module holds learnable parameters and must be constructed once
    per (student, teacher) pair and passed to the optimizer alongside the
    student's own parameters.
    """

    def __init__(self, student_dim: int, teacher_dim: int):
        super().__init__()
        self.regressor = nn.Linear(student_dim, teacher_dim)

    def forward(self, student_feature: torch.Tensor) -> torch.Tensor:
        return self.regressor(student_feature)


def feature_distillation_loss(
    student_pooled_feature: torch.Tensor,
    teacher_pooled_feature: torch.Tensor,
    adapter: FeatureAdapter,
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    targets: torch.Tensor,
    alpha: float,
    temperature: float,
    beta_feature: float,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """FitNets-style hint loss on pooled features, combined with vanilla KD
    on the logits and hard-label CE.
    """
    projected = adapter(student_pooled_feature)
    hint_loss = F.mse_loss(projected, teacher_pooled_feature.detach())

    kd, kd_stats = vanilla_kd_loss(student_logits, teacher_logits, targets, alpha, temperature)
    total = kd + beta_feature * hint_loss

    stats = dict(kd_stats)
    stats["hint_loss"] = hint_loss.item()
    stats["total_loss"] = total.item()
    return total, stats


def attention_transfer_loss(student_attention_map: torch.Tensor, teacher_attention_map: torch.Tensor) -> torch.Tensor:
    """MSE between two spatial attention maps of possibly different
    resolutions (e.g. a CNN stage's HxW map vs. a ViT's patch-grid map).
    The student's map is resized to the teacher's resolution and both are
    L2-normalized per sample before comparison, following Zagoruyko &
    Komodakis (2017).
    """
    b = teacher_attention_map.shape[0]
    target_size = teacher_attention_map.shape[-2:]

    student_map = student_attention_map.unsqueeze(1)  # (B, 1, H, W)
    student_map = F.interpolate(student_map, size=target_size, mode="bilinear", align_corners=False)
    student_map = student_map.squeeze(1)

    def _l2_normalize(m: torch.Tensor) -> torch.Tensor:
        flat = m.reshape(b, -1)
        flat = F.normalize(flat, p=2, dim=1)
        return flat.view_as(m)

    student_map = _l2_normalize(student_map)
    teacher_map = _l2_normalize(teacher_attention_map)

    return F.mse_loss(student_map, teacher_map)


def combined_attention_transfer_loss(
    student_logits: torch.Tensor,
    teacher_logits: torch.Tensor,
    targets: torch.Tensor,
    student_attention_maps: List[torch.Tensor],
    teacher_attention_maps: List[torch.Tensor],
    alpha: float,
    temperature: float,
    beta_attention: float,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    """Vanilla KD on the logits + attention-transfer loss averaged over every
    matched (student_map, teacher_map) pair. When the two models produce a
    different number of attention maps (e.g. a 3-stage CNN vs. a single
    final ViT attention map), maps are matched from the end -- i.e. the
    deepest / most semantic maps are compared first.
    """
    kd, kd_stats = vanilla_kd_loss(student_logits, teacher_logits, targets, alpha, temperature)

    n_pairs = min(len(student_attention_maps), len(teacher_attention_maps))
    if n_pairs == 0:
        at_loss = torch.zeros((), device=student_logits.device)
    else:
        student_matched = student_attention_maps[-n_pairs:]
        teacher_matched = teacher_attention_maps[-n_pairs:]
        at_loss = sum(
            attention_transfer_loss(s, t) for s, t in zip(student_matched, teacher_matched)
        ) / n_pairs

    total = kd + beta_attention * at_loss

    stats = dict(kd_stats)
    stats["attention_transfer_loss"] = float(at_loss)
    stats["total_loss"] = total.item()
    return total, stats
