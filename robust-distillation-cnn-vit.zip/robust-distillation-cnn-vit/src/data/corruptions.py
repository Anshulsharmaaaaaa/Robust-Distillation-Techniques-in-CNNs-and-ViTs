"""Synthetic, dependency-light stand-ins for the CIFAR-10-C / CIFAR-100-C
common-corruptions benchmark (Hendrycks & Dietterich, 2019), so robustness
can be measured without downloading a separate multi-GB corrupted dataset.

Each corruption is a function `(x: (B,C,H,W) tensor in [0,1], severity: int
1-5) -> corrupted tensor in [0,1]`. Swap these for the official CIFAR-10-C
tensors in src/data/datasets.py if exact reproducibility with published
numbers is required -- see the Roadmap in README.md.
"""

from __future__ import annotations

import io
from typing import Callable, Dict

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image


def gaussian_noise(x: torch.Tensor, severity: int) -> torch.Tensor:
    std = [0.02, 0.04, 0.06, 0.09, 0.12][severity - 1]
    noise = torch.randn_like(x) * std
    return torch.clamp(x + noise, 0.0, 1.0)


def gaussian_blur(x: torch.Tensor, severity: int) -> torch.Tensor:
    sigma = [0.4, 0.8, 1.2, 1.6, 2.0][severity - 1]
    kernel_size = max(3, int(2 * round(3 * sigma) + 1))
    channels = x.shape[1]

    coords = torch.arange(kernel_size, dtype=x.dtype, device=x.device) - kernel_size // 2
    g = torch.exp(-(coords ** 2) / (2 * sigma ** 2))
    g = g / g.sum()

    kernel_h = g.view(1, 1, 1, kernel_size).repeat(channels, 1, 1, 1)
    kernel_v = g.view(1, 1, kernel_size, 1).repeat(channels, 1, 1, 1)

    pad = kernel_size // 2
    out = F.conv2d(x, kernel_h, padding=(0, pad), groups=channels)
    out = F.conv2d(out, kernel_v, padding=(pad, 0), groups=channels)
    return torch.clamp(out, 0.0, 1.0)


def brightness(x: torch.Tensor, severity: int) -> torch.Tensor:
    delta = [0.06, 0.12, 0.18, 0.24, 0.32][severity - 1]
    return torch.clamp(x + delta, 0.0, 1.0)


def contrast(x: torch.Tensor, severity: int) -> torch.Tensor:
    factor = [0.75, 0.6, 0.45, 0.3, 0.15][severity - 1]
    mean = x.mean(dim=(2, 3), keepdim=True)
    return torch.clamp((x - mean) * factor + mean, 0.0, 1.0)


def jpeg_compression(x: torch.Tensor, severity: int) -> torch.Tensor:
    """Round-trips each image through low-quality JPEG encoding via PIL to
    introduce blocking / quantization artifacts. Slower than the other
    corruptions (a CPU round trip per image) -- fine for evaluation-time use.
    """
    quality = [80, 65, 50, 30, 15][severity - 1]
    x_cpu = x.detach().cpu()
    out = torch.empty_like(x_cpu)

    for i in range(x_cpu.shape[0]):
        img = (x_cpu[i].permute(1, 2, 0).numpy() * 255).astype(np.uint8)
        pil_img = Image.fromarray(img)
        buffer = io.BytesIO()
        pil_img.save(buffer, format="JPEG", quality=quality)
        buffer.seek(0)
        decoded = Image.open(buffer).convert("RGB")
        arr = np.array(decoded).astype(np.float32) / 255.0
        out[i] = torch.from_numpy(arr).permute(2, 0, 1)

    return out.to(x.device)


def occlusion(x: torch.Tensor, severity: int) -> torch.Tensor:
    """Random gray patch occlusion -- a stand-in for CIFAR-C's fog / object
    occlusion style corruptions.
    """
    patch_frac = [0.1, 0.15, 0.2, 0.28, 0.36][severity - 1]
    b, c, h, w = x.shape
    out = x.clone()
    patch_h = max(1, int(h * patch_frac))
    patch_w = max(1, int(w * patch_frac))

    for i in range(b):
        top = int(torch.randint(0, h - patch_h + 1, (1,)).item())
        left = int(torch.randint(0, w - patch_w + 1, (1,)).item())
        out[i, :, top:top + patch_h, left:left + patch_w] = 0.5

    return out


CORRUPTIONS: Dict[str, Callable[[torch.Tensor, int], torch.Tensor]] = {
    "gaussian_noise": gaussian_noise,
    "gaussian_blur": gaussian_blur,
    "brightness": brightness,
    "contrast": contrast,
    "jpeg_compression": jpeg_compression,
    "occlusion": occlusion,
}

SEVERITIES = (1, 2, 3, 4, 5)


def apply_corruption(x: torch.Tensor, name: str, severity: int) -> torch.Tensor:
    if name not in CORRUPTIONS:
        raise ValueError(f"Unknown corruption '{name}'. Available: {sorted(CORRUPTIONS.keys())}")
    if severity not in SEVERITIES:
        raise ValueError("severity must be an integer 1-5")
    return CORRUPTIONS[name](x, severity)
