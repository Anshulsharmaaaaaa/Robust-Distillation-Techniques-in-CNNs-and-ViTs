"""CIFAR-10 / CIFAR-100 data loading.

Images are kept in [0, 1] (`ToTensor` only -- no mean/std normalization) so
that every adversarial attack's epsilon-ball and pixel clipping in
src/attacks/adversarial.py operate directly in true pixel space. BatchNorm
(CNN) and LayerNorm (ViT) inside the models provide the equivalent of input
normalization internally, so accuracy is not affected by skipping it here.
"""

from __future__ import annotations

from typing import Tuple

import torch
import torchvision
import torchvision.transforms as T
from torch.utils.data import DataLoader, random_split

_NUM_CLASSES = {"cifar10": 10, "cifar100": 100}


def num_classes_for(dataset_name: str) -> int:
    return _NUM_CLASSES[dataset_name.lower()]


def _train_transform(image_size: int) -> T.Compose:
    return T.Compose([
        T.RandomCrop(image_size, padding=4, padding_mode="reflect"),
        T.RandomHorizontalFlip(),
        T.ToTensor(),
    ])


def _eval_transform(image_size: int) -> T.Compose:
    return T.Compose([T.ToTensor()])


def build_dataloaders(cfg: dict) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """Returns (train_loader, val_loader, test_loader) built from the `data:`
    section of a config (see configs/base.yaml).
    """
    data_cfg = cfg["data"]
    dataset_name = data_cfg["dataset"].lower()
    image_size = data_cfg["image_size"]

    if dataset_name == "cifar10":
        dataset_cls = torchvision.datasets.CIFAR10
    elif dataset_name == "cifar100":
        dataset_cls = torchvision.datasets.CIFAR100
    else:
        raise ValueError(f"Unsupported dataset '{dataset_name}'. Use 'cifar10' or 'cifar100'.")

    full_train = dataset_cls(
        root=data_cfg["data_dir"], train=True, download=True, transform=_train_transform(image_size)
    )
    test_set = dataset_cls(
        root=data_cfg["data_dir"], train=False, download=True, transform=_eval_transform(image_size)
    )

    val_fraction = data_cfg.get("val_split", 0.1)
    val_size = int(len(full_train) * val_fraction)
    train_size = len(full_train) - val_size
    generator = torch.Generator().manual_seed(cfg.get("seed", 42))
    train_set, val_set = random_split(full_train, [train_size, val_size], generator=generator)

    # The validation split should use eval-style (non-augmented) transforms;
    # torchvision loads CIFAR from disk in a fixed order, so swapping the
    # underlying dataset keeps the same images/labels under the Subset's
    # stored indices while dropping random-crop/flip augmentation.
    val_set.dataset = dataset_cls(
        root=data_cfg["data_dir"], train=True, download=False, transform=_eval_transform(image_size)
    )

    train_loader = DataLoader(
        train_set, batch_size=data_cfg["batch_size"], shuffle=True,
        num_workers=data_cfg.get("num_workers", 4), pin_memory=True, drop_last=True,
    )
    val_loader = DataLoader(
        val_set, batch_size=data_cfg.get("eval_batch_size", 256), shuffle=False,
        num_workers=data_cfg.get("num_workers", 4), pin_memory=True,
    )
    test_loader = DataLoader(
        test_set, batch_size=data_cfg.get("eval_batch_size", 256), shuffle=False,
        num_workers=data_cfg.get("num_workers", 4), pin_memory=True,
    )
    return train_loader, val_loader, test_loader
