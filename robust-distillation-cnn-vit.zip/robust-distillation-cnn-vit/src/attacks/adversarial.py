"""FGSM and PGD (L-infinity) adversarial attacks.

Both attacks perturb the input by ascending the gradient of a loss with
respect to the input, then clip to stay within an L-infinity ball of radius
`epsilon` and within the valid image range [0, 1].

By default the loss being maximized is standard cross-entropy against the
true label `y` (the usual adversarial-training / evaluation attack). Passing
a custom `loss_fn(logits) -> scalar` lets the attack target something else
instead -- e.g. divergence from a teacher's soft label, as used by the
robust distillation loss in src/distillation/robust.py.
"""

from __future__ import annotations

from typing import Callable, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


def _default_loss(logits: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits, y)


def fgsm_attack(
    model: nn.Module,
    x: torch.Tensor,
    y: Optional[torch.Tensor],
    epsilon: float,
    loss_fn: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
) -> torch.Tensor:
    """Single-step Fast Gradient Sign Method attack (Goodfellow et al., 2015)."""
    x_adv = x.clone().detach().requires_grad_(True)
    logits = model(x_adv)
    loss = loss_fn(logits) if loss_fn is not None else _default_loss(logits, y)

    grad = torch.autograd.grad(loss, x_adv)[0]
    x_adv = x_adv.detach() + epsilon * grad.sign()
    x_adv = torch.clamp(x_adv, 0.0, 1.0)
    return x_adv.detach()


def pgd_attack(
    model: nn.Module,
    x: torch.Tensor,
    y: Optional[torch.Tensor],
    epsilon: float,
    step_size: float,
    num_steps: int = 10,
    random_start: bool = True,
    loss_fn: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
) -> torch.Tensor:
    """Multi-step Projected Gradient Descent attack, L-infinity ball
    (Madry et al., 2018).
    """
    x_orig = x.clone().detach()

    if random_start:
        delta = torch.empty_like(x_orig).uniform_(-epsilon, epsilon)
        x_adv = torch.clamp(x_orig + delta, 0.0, 1.0).detach()
    else:
        x_adv = x_orig.clone().detach()

    for _ in range(num_steps):
        x_adv.requires_grad_(True)
        logits = model(x_adv)
        loss = loss_fn(logits) if loss_fn is not None else _default_loss(logits, y)

        grad = torch.autograd.grad(loss, x_adv)[0]
        x_adv = x_adv.detach() + step_size * grad.sign()

        # Project back into the epsilon L-infinity ball around x_orig, then
        # clip to the valid pixel range.
        perturbation = torch.clamp(x_adv - x_orig, -epsilon, epsilon)
        x_adv = torch.clamp(x_orig + perturbation, 0.0, 1.0).detach()

    return x_adv
