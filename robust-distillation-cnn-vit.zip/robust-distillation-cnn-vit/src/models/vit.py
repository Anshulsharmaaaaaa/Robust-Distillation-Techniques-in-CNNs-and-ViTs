"""Vision Transformer for small images (CIFAR-10/100), configurable from a
tiny "student" to a full-size "teacher" via `(embed_dim, depth, num_heads)`.

Implemented from scratch (patch embedding + pre-norm transformer encoder +
CLS token) rather than wrapping an external library, so the whole forward
pass — including per-layer self-attention maps — is transparent and easy to
hook into for distillation.

Every forward pass can optionally return:
  - `features`: the CLS-token hidden state after a few chosen encoder blocks
    (used by feature/hint distillation), and
  - `attention_maps`: the CLS token's attention-over-patches for the last
    encoder block, reshaped to a spatial grid (used by attention-transfer
    distillation to compare against a CNN's spatial attention map).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

import torch
import torch.nn as nn


class PatchEmbedding(nn.Module):
    def __init__(self, image_size: int, patch_size: int, in_channels: int, embed_dim: int):
        super().__init__()
        assert image_size % patch_size == 0, "image_size must be divisible by patch_size"
        self.grid_size = image_size // patch_size
        self.num_patches = self.grid_size ** 2
        self.proj = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)                 # (B, embed_dim, grid, grid)
        x = x.flatten(2).transpose(1, 2)  # (B, num_patches, embed_dim)
        return x


class MultiHeadSelfAttention(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int, attn_dropout: float = 0.0, proj_dropout: float = 0.0):
        super().__init__()
        assert embed_dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(embed_dim, embed_dim * 3, bias=True)
        self.attn_dropout = nn.Dropout(attn_dropout)
        self.proj = nn.Linear(embed_dim, embed_dim)
        self.proj_dropout = nn.Dropout(proj_dropout)

    def forward(self, x: torch.Tensor):
        b, n, c = x.shape
        qkv = self.qkv(x).reshape(b, n, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # each: (B, heads, N, head_dim)

        attn_logits = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn_logits.softmax(dim=-1)
        attn = self.attn_dropout(attn)

        out = (attn @ v).transpose(1, 2).reshape(b, n, c)
        out = self.proj_dropout(self.proj(out))
        return out, attn  # attn: (B, heads, N, N) — used for attention-transfer


class MLP(nn.Module):
    def __init__(self, embed_dim: int, mlp_ratio: float = 4.0, dropout: float = 0.0):
        super().__init__()
        hidden = int(embed_dim * mlp_ratio)
        self.net = nn.Sequential(
            nn.Linear(embed_dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, embed_dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class TransformerBlock(nn.Module):
    def __init__(self, embed_dim: int, num_heads: int, mlp_ratio: float = 4.0, dropout: float = 0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(embed_dim)
        self.attn = MultiHeadSelfAttention(embed_dim, num_heads, attn_dropout=dropout, proj_dropout=dropout)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.mlp = MLP(embed_dim, mlp_ratio, dropout=dropout)

    def forward(self, x: torch.Tensor):
        attn_out, attn_weights = self.attn(self.norm1(x))
        x = x + attn_out
        x = x + self.mlp(self.norm2(x))
        return x, attn_weights


@dataclass
class ViTOutput:
    logits: torch.Tensor
    features: List[torch.Tensor] = field(default_factory=list)        # CLS hidden states, selected layers
    pooled_feature: Optional[torch.Tensor] = None                      # final CLS token (pre-head)
    attention_maps: List[torch.Tensor] = field(default_factory=list)    # spatial CLS-attention, last block


class VisionTransformer(nn.Module):
    def __init__(
        self,
        image_size: int = 32,
        patch_size: int = 4,
        in_channels: int = 3,
        num_classes: int = 10,
        embed_dim: int = 192,
        depth: int = 12,
        num_heads: int = 3,
        mlp_ratio: float = 4.0,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.patch_embed = PatchEmbedding(image_size, patch_size, in_channels, embed_dim)
        num_patches = self.patch_embed.num_patches
        self.grid_size = self.patch_embed.grid_size

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
        self.pos_dropout = nn.Dropout(dropout)

        self.blocks = nn.ModuleList(
            [TransformerBlock(embed_dim, num_heads, mlp_ratio, dropout) for _ in range(depth)]
        )
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)

        self.feature_dim = embed_dim
        self._init_weights()

    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def cls_attention_to_grid(self, attn_weights: torch.Tensor) -> torch.Tensor:
        """Turn the CLS token's attention over patch tokens into a spatial
        (B, grid, grid) map, averaged over heads — comparable to a CNN's
        `spatial_attention_map` output (see src/models/cnn.py).
        """
        # attn_weights: (B, heads, N, N), N = num_patches + 1 (CLS is index 0)
        cls_to_patches = attn_weights[:, :, 0, 1:]        # (B, heads, num_patches)
        cls_to_patches = cls_to_patches.mean(dim=1)         # (B, num_patches)
        b = cls_to_patches.shape[0]
        return cls_to_patches.view(b, self.grid_size, self.grid_size)

    def forward(self, x: torch.Tensor, return_features: bool = False):
        b = x.shape[0]
        tokens = self.patch_embed(x)
        cls_tokens = self.cls_token.expand(b, -1, -1)
        tokens = torch.cat([cls_tokens, tokens], dim=1)
        tokens = tokens + self.pos_embed
        tokens = self.pos_dropout(tokens)

        features: List[torch.Tensor] = []
        last_attn: Optional[torch.Tensor] = None
        checkpoints = {len(self.blocks) // 2, len(self.blocks) - 1}  # mid-layer + final, for hint loss

        for i, block in enumerate(self.blocks):
            tokens, attn_weights = block(tokens)
            if i in checkpoints:
                features.append(tokens[:, 0])  # CLS hidden state at this depth
            last_attn = attn_weights

        tokens = self.norm(tokens)
        cls_final = tokens[:, 0]
        logits = self.head(cls_final)

        if not return_features:
            return logits

        attention_maps = [self.cls_attention_to_grid(last_attn)] if last_attn is not None else []
        return ViTOutput(logits=logits, features=features, pooled_feature=cls_final, attention_maps=attention_maps)


# ---------------------------------------------------------------------------
# Named factory presets — used by src/models/factory.py
# ---------------------------------------------------------------------------

def vit_tiny(num_classes: int = 10, image_size: int = 32) -> VisionTransformer:
    """Compact ViT student (~1.1M params): embed_dim=96, depth=6, heads=3."""
    return VisionTransformer(
        image_size=image_size, patch_size=4, num_classes=num_classes,
        embed_dim=96, depth=6, num_heads=3, mlp_ratio=4.0, dropout=0.0,
    )


def vit_small(num_classes: int = 10, image_size: int = 32) -> VisionTransformer:
    """Full-size ViT teacher (~7M params): embed_dim=192, depth=12, heads=3."""
    return VisionTransformer(
        image_size=image_size, patch_size=4, num_classes=num_classes,
        embed_dim=192, depth=12, num_heads=3, mlp_ratio=4.0, dropout=0.1,
    )
