"""ResNet-style CNN for small images (CIFAR-10/100), configurable from a
tiny "student" width/depth up to a full-size "teacher".

A single class (`ResNetCIFAR`) parameterized by `(depth, width_mult)` is used
for both roles so that every experiment compares distillation *techniques*
rather than unrelated CNN implementations. Depth follows the standard
CIFAR-ResNet convention: depth = 6n + 2 (e.g. depth=20 -> n=3, depth=56 -> n=9).

Every forward pass optionally returns intermediate feature maps and a
CNN-style "spatial attention map" (mean of squared activations across
channels), used by the feature-based and attention-transfer distillation
losses in `src/distillation/losses.py`.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def spatial_attention_map(feature_map: torch.Tensor) -> torch.Tensor:
    """Collapse a (B, C, H, W) feature map into a (B, H, W) attention map.

    Uses the sum of squared activations across channels (Zagoruyko &
    Komodakis, 2017), then flattens and L2-normalizes per-sample so that
    attention-transfer loss is scale-invariant.
    """
    attn = feature_map.pow(2).mean(dim=1)  # (B, H, W)
    b = attn.shape[0]
    attn_flat = attn.view(b, -1)
    attn_flat = F.normalize(attn_flat, p=2, dim=1)
    return attn_flat.view_as(attn)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes: int, planes: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != planes * self.expansion:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, planes * self.expansion, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * self.expansion),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = out + self.shortcut(x)
        return F.relu(out)


@dataclass
class ResNetCIFAROutput:
    logits: torch.Tensor
    features: List[torch.Tensor]        # feature maps after each stage
    pooled_feature: torch.Tensor        # feature vector fed to the classifier
    attention_maps: List[torch.Tensor]  # spatial attention derived from `features`


class ResNetCIFAR(nn.Module):
    """CIFAR-style ResNet. depth = 6n + 2, three stages of widths
    (16, 32, 64) * width_mult, each downsampling spatially by 2 except the
    first stage.
    """

    def __init__(self, depth: int = 56, num_classes: int = 10, width_mult: float = 1.0):
        super().__init__()
        assert (depth - 2) % 6 == 0, "depth must be 6n + 2 (e.g. 20, 32, 44, 56, 110)"
        n = (depth - 2) // 6

        widths = [int(16 * width_mult), int(32 * width_mult), int(64 * width_mult)]
        self.in_planes = widths[0]

        self.conv1 = nn.Conv2d(3, widths[0], kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(widths[0])

        self.stage1 = self._make_stage(widths[0], n, stride=1)
        self.stage2 = self._make_stage(widths[1], n, stride=2)
        self.stage3 = self._make_stage(widths[2], n, stride=2)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(widths[2], num_classes)

        self.feature_dim = widths[2]
        self._init_weights()

    def _make_stage(self, planes: int, num_blocks: int, stride: int) -> nn.Sequential:
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for s in strides:
            layers.append(BasicBlock(self.in_planes, planes, stride=s))
            self.in_planes = planes * BasicBlock.expansion
        return nn.Sequential(*layers)

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor, return_features: bool = False):
        out = F.relu(self.bn1(self.conv1(x)))
        f1 = self.stage1(out)
        f2 = self.stage2(f1)
        f3 = self.stage3(f2)

        pooled = self.avgpool(f3).flatten(1)
        logits = self.fc(pooled)

        if not return_features:
            return logits

        features = [f1, f2, f3]
        attention_maps = [spatial_attention_map(f) for f in features]
        return ResNetCIFAROutput(
            logits=logits, features=features, pooled_feature=pooled, attention_maps=attention_maps
        )


# ---------------------------------------------------------------------------
# Named factory presets — used by src/models/factory.py
# ---------------------------------------------------------------------------

def resnet20(num_classes: int = 10) -> ResNetCIFAR:
    """Compact CNN student (~0.27M params)."""
    return ResNetCIFAR(depth=20, num_classes=num_classes, width_mult=1.0)


def resnet56(num_classes: int = 10) -> ResNetCIFAR:
    """Full-size CNN teacher (~0.85M params)."""
    return ResNetCIFAR(depth=56, num_classes=num_classes, width_mult=1.0)


def resnet110(num_classes: int = 10) -> ResNetCIFAR:
    """Larger CNN teacher for stronger-teacher ablations (~1.7M params)."""
    return ResNetCIFAR(depth=110, num_classes=num_classes, width_mult=1.0)
