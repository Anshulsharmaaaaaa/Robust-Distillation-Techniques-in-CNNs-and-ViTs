"""Single entry point for building any model used in this project by name.

Keeping construction in one place means the training script never needs to
know whether a given name is a CNN or a ViT — it just calls `build_model(name,
num_classes)` and gets back an `nn.Module` whose `forward(x, return_features=True)`
returns a `.logits` tensor plus `.features` / `.attention_maps` for
distillation.
"""

from __future__ import annotations

from typing import Callable, Dict

import torch.nn as nn

from .cnn import ResNetCIFAR, resnet20, resnet56, resnet110
from .vit import VisionTransformer, vit_tiny, vit_small

_REGISTRY: Dict[str, Callable[..., nn.Module]] = {
    "resnet20": resnet20,
    "resnet56": resnet56,
    "resnet110": resnet110,
    "vit_tiny": vit_tiny,
    "vit_small": vit_small,
}


def build_model(name: str, num_classes: int = 10, **kwargs) -> nn.Module:
    """Build a registered model by name.

    Args:
        name: one of the keys in `_REGISTRY` (see above).
        num_classes: output classes (10 for CIFAR-10, 100 for CIFAR-100).
        **kwargs: forwarded to the underlying constructor (e.g. `image_size`
            for ViT variants on non-32x32 inputs).
    """
    if name not in _REGISTRY:
        raise ValueError(f"Unknown model '{name}'. Available: {sorted(_REGISTRY.keys())}")
    return _REGISTRY[name](num_classes=num_classes, **kwargs)


def is_cnn(model: nn.Module) -> bool:
    return isinstance(model, ResNetCIFAR)


def is_vit(model: nn.Module) -> bool:
    return isinstance(model, VisionTransformer)


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
