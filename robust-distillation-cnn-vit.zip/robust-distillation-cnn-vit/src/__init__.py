"""Robust Distillation Techniques in CNNs and ViTs.

A config-driven framework for distilling knowledge between CNN and Vision
Transformer image classifiers, with a focus on adversarial and
distribution-shift robustness rather than clean accuracy alone.
"""

__version__ = "0.1.0"
