# Robust Distillation Techniques in CNNs and ViTs

Knowledge distillation across **Convolutional Neural Networks (CNNs)** and **Vision Transformers (ViTs)**, with an emphasis on **robustness** — accuracy that survives adversarial perturbations and common corruptions, not just clean test accuracy.

> Standard KD asks: *"can a small model mimic a big model's predictions?"*
> This project asks: *"can a small model mimic a big model's predictions **and** keep working when the input is noisy, blurred, or adversarially attacked — even when the teacher and student belong to different architecture families?"*

---

## Table of Contents

- [Overview](#overview)
- [Key Features](#key-features)
- [Techniques Implemented](#techniques-implemented)
- [Repository Structure](#repository-structure)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Configuration System](#configuration-system)
- [Evaluating Robustness](#evaluating-robustness)
- [Results](#results)
- [Methodology](#methodology)
- [Testing](#testing)
- [Roadmap](#roadmap)
- [References](#references)
- [License](#license)
- [Author](#author)

---

## Overview

CNNs and ViTs learn very different inductive biases: CNNs rely on local, translation-equivariant convolutions, while ViTs rely on global self-attention over image patches. This difference shows up not only in clean accuracy but in **what each architecture is robust to** — CNNs tend to be more texture-biased and vulnerable to certain corruptions, while ViTs tend to be more shape-biased but data-hungry and expensive.

This project builds a single, config-driven framework to:

1. Train CNN and ViT **teacher** models on an image classification benchmark (CIFAR-10 / CIFAR-100 by default, easily extendable).
2. Compress them into smaller CNN/ViT **student** models using several distillation strategies — including **cross-architecture** distillation (CNN → ViT and ViT → CNN).
3. Make that distillation **robustness-aware**, using adversarial and feature-alignment objectives rather than plain logit matching.
4. Evaluate every resulting student on three axes: **clean accuracy**, **adversarial robust accuracy** (FGSM / PGD), and **corruption robustness** (synthetic CIFAR-C-style corruptions at multiple severities).

The goal is a reusable research/engineering scaffold — swap in a new architecture, a new distillation loss, or a new attack, and the training/evaluation loop keeps working.

## Key Features

- **Architecture-agnostic model factory** — one `ResNetCIFAR` implementation and one `VisionTransformer` implementation, each configurable from tiny (student) to full-size (teacher), so every experiment is an apples-to-apples comparison of *technique*, not of unrelated codebases.
- **Four distillation strategies**, composable via config: vanilla response-based KD, feature/hint-based distillation, attention transfer (bridged across CNN spatial attention and ViT self-attention), and adversarially robust distillation (ARD / RSLAD-style).
- **Cross-architecture distillation** — a CNN teacher can supervise a ViT student and vice versa, with a learned adapter that projects one representation space into the other.
- **Built-in adversarial attacks** (FGSM, PGD-ℓ∞) for both generating robust-training examples and for evaluation.
- **Synthetic corruption benchmark** (Gaussian noise, motion-style blur, brightness/contrast shift, JPEG-style quantization, occlusion) at 5 severities, so robustness can be measured without a separate multi-GB dataset download.
- **Fully config-driven** experiments (YAML in `configs/`) — no hard-coded hyperparameters in the training script.
- **Unit-tested core** (`tests/`) so model shapes, loss values, and attack outputs are verified independently of a full training run.

## Techniques Implemented

| # | Technique | Reference | What it aligns |
|---|-----------|-----------|-----------------|
| 1 | Vanilla Response-Based KD | Hinton et al., 2015 | Softened output logits (KL divergence + temperature) |
| 2 | Feature-Based / Hint Distillation | Romero et al. (FitNets), 2015 | Intermediate feature maps via a learned regressor/adapter |
| 3 | Attention Transfer (cross-architecture) | Zagoruyko & Komodakis, 2017; adapted here for CNN↔ViT | Spatial "where the network looks" attention maps |
| 4 | Adversarially Robust Distillation (ARD / RSLAD) | Goldblum et al., 2020; Zi et al., 2021 | Teacher's soft labels on adversarial examples, transferred to a student trained under attack |

Each technique lives in `src/distillation/` behind a common interface (`compute_loss(student_out, teacher_out, batch, model_pair)`), so the trainer doesn't need to know which one is active — it's selected purely by config.

## Repository Structure

```
robust-distillation-cnn-vit/
├── README.md                      # you are here
├── LICENSE
├── requirements.txt
├── setup.py
├── .gitignore
│
├── configs/                       # one YAML per experiment — nothing hard-coded in code
│   ├── base.yaml                  # shared defaults (data, optimizer, schedule)
│   ├── kd_resnet_teacher_vit_student.yaml
│   ├── feature_distillation.yaml
│   ├── attention_transfer.yaml
│   └── robust_adversarial_distillation.yaml
│
├── src/
│   ├── models/
│   │   ├── cnn.py                 # ResNetCIFAR (configurable depth/width) — teacher & student
│   │   ├── vit.py                 # VisionTransformer (configurable depth/heads/dim) — teacher & student
│   │   └── factory.py             # build_model(name, role) -> nn.Module
│   │
│   ├── distillation/
│   │   ├── losses.py              # vanilla KD, feature/hint loss, attention transfer loss
│   │   └── robust.py              # ARD / RSLAD adversarial distillation objective
│   │
│   ├── attacks/
│   │   └── adversarial.py         # FGSM, PGD-ℓ∞
│   │
│   ├── data/
│   │   ├── datasets.py            # CIFAR-10/100 loaders, train/val split
│   │   └── corruptions.py         # synthetic CIFAR-C-style corruption transforms
│   │
│   ├── engine/
│   │   ├── trainer.py             # generic train loop (baseline + distillation modes)
│   │   └── evaluator.py           # clean / adversarial / corruption evaluation
│   │
│   └── utils/
│       ├── logger.py              # run logging (console + CSV)
│       ├── metrics.py             # accuracy, AverageMeter
│       ├── seed.py                # reproducibility
│       └── visualization.py       # training curves, attention-map plots
│
├── scripts/
│   ├── train.py                   # entry point: python scripts/train.py --config configs/...
│   ├── evaluate.py                # entry point: robustness evaluation of a checkpoint
│   └── plot_results.py            # turn logged CSVs into comparison plots/tables
│
├── tests/
│   ├── test_models.py             # shape/forward-pass checks for CNN & ViT
│   ├── test_losses.py             # numerical sanity checks for each distillation loss
│   └── test_attacks.py            # FGSM/PGD produce valid, bounded perturbations
│
├── docs/
│   └── METHODOLOGY.md             # the math behind each loss, design decisions, trade-offs
│
├── notebooks/
│   └── demo_visualization.ipynb   # loads a run's logs and renders comparison plots
│
└── results/                       # populated by training/eval runs (git-ignored except .gitkeep)
```

## Installation

```bash
git clone https://github.com/Anshulsharmaaaaaa/robust-distillation-cnn-vit.git
cd robust-distillation-cnn-vit

python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

pip install -r requirements.txt
pip install -e .                 # editable install so `src` is importable as a package
```

Tested against Python 3.10+ and PyTorch 2.x. A CUDA-capable GPU is strongly recommended for the ViT experiments; everything also runs on CPU at reduced batch size for debugging.

## Quick Start

Train a CNN teacher (ResNet-56 on CIFAR-10):

```bash
python scripts/train.py --config configs/base.yaml --model resnet56 --role teacher --run-name resnet56_teacher
```

Distill a ViT-Tiny student from that CNN teacher with vanilla KD:

```bash
python scripts/train.py --config configs/kd_resnet_teacher_vit_student.yaml \
    --teacher-ckpt results/resnet56_teacher/best.pt
```

Distill a compact CNN student from a ViT teacher with feature/hint distillation (note the direction reverses here — see `configs/feature_distillation.yaml`):

```bash
python scripts/train.py --config configs/feature_distillation.yaml \
    --teacher-ckpt results/vit_small_teacher/best.pt
```

Run the ResNet→ViT distillation again with attention transfer instead of plain KD:

```bash
python scripts/train.py --config configs/attention_transfer.yaml \
    --teacher-ckpt results/resnet56_teacher/best.pt
```

Train a robustness-aware student with adversarial distillation (ARD/RSLAD):

```bash
python scripts/train.py --config configs/robust_adversarial_distillation.yaml \
    --teacher-ckpt results/resnet56_teacher/best.pt
```

Evaluate any checkpoint on clean, adversarial, and corrupted test sets:

```bash
python scripts/evaluate.py --checkpoint results/vit_tiny_student/best.pt --attack pgd --corruptions all
```

## Configuration System

Every experiment is a YAML file under `configs/`. `base.yaml` holds shared defaults (dataset, batch size, optimizer, LR schedule, seed); experiment-specific configs inherit from it and override only what changes — the distillation `method`, loss weights (`alpha`, `temperature`, `beta_feature`, `beta_attention`), and attack parameters (`epsilon`, `pgd_steps`, `step_size`) for robust training. See the comments in `configs/base.yaml` for every field.

## Evaluating Robustness

`src/engine/evaluator.py` reports three numbers per checkpoint:

- **Clean accuracy** — standard top-1 on the unmodified test set.
- **Robust accuracy** — top-1 under FGSM and PGD-ℓ∞ (default ε = 8/255, 20 steps, step size = 2/255 for PGD).
- **Corruption accuracy** — mean top-1 across `src/data/corruptions.py`'s corruption types × 5 severities, reported as **mCE-style** relative degradation from clean accuracy.

`scripts/evaluate.py --corruptions all` runs the full suite and writes a CSV to `results/<run-name>/robustness_report.csv`; `scripts/plot_results.py` turns one or more of those CSVs into a comparison bar chart.

## Results

This scaffold ships without pre-run numbers — fill this table in after running your own experiments (`scripts/plot_results.py --markdown` will generate it for you):

| Teacher → Student | Method | Params (M) | Clean Acc. | PGD-20 Acc. | Mean Corruption Acc. |
|---|---|---|---|---|---|
| ResNet-56 → ResNet-20 | Vanilla KD | — | — | — | — |
| ResNet-56 → ViT-Tiny | Attention Transfer | — | — | — | — |
| ViT-Small → ResNet-20 | Feature Distillation | — | — | — | — |
| ResNet-56 → ViT-Tiny | ARD (robust) | — | — | — | — |

## Methodology

The mathematical formulation of each loss, the design choice behind the cross-architecture adapter, and the corruption-generation procedure are documented in [`docs/METHODOLOGY.md`](docs/METHODOLOGY.md).

## Testing

```bash
pytest tests/ -v
```

Tests are pure shape/numerical checks — they run on CPU in seconds and don't require a dataset download, so they're safe to run in CI.

## Roadmap

- [ ] Add DeiT-style distillation token as a fifth strategy.
- [ ] Swap synthetic corruptions for official CIFAR-10-C / CIFAR-100-C tensors.
- [ ] Extend `src/data/datasets.py` to Tiny-ImageNet.
- [ ] Add a GitHub Actions workflow that runs `pytest` on push.
- [ ] Log runs to Weights & Biases / TensorBoard as an alternative to the CSV logger.

## References

1. Hinton, G., Vinyals, O., & Dean, J. (2015). *Distilling the Knowledge in a Neural Network.*
2. Romero, A. et al. (2015). *FitNets: Hints for Thin Deep Nets.*
3. Zagoruyko, S., & Komodakis, N. (2017). *Paying More Attention to Attention: Improving CNN Transfer via Attention Transfer.*
4. Goldblum, M. et al. (2020). *Adversarially Robust Distillation.*
5. Zi, B., Zhao, S., et al. (2021). *Revisiting Adversarial Robustness Distillation: Robust Soft Labels Make Student Better (RSLAD).*
6. Dosovitskiy, A. et al. (2021). *An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale.*
7. Touvron, H. et al. (2021). *Training Data-Efficient Image Transformers & Distillation Through Attention (DeiT).*
8. Hendrycks, D., & Dietterich, T. (2019). *Benchmarking Neural Network Robustness to Common Corruptions and Perturbations.*
9. Madry, A. et al. (2018). *Towards Deep Learning Models Resistant to Adversarial Attacks.*

## License

Released under the [MIT License](LICENSE).

## Author

**Anshul Sharma**
B.Tech, Computer Science & Engineering — Amity University
GitHub: [@Anshulsharmaaaaaa](https://github.com/Anshulsharmaaaaaa) · LinkedIn: [Anshulsharma23](https://www.linkedin.com/in/Anshulsharma23)

Contributions and issues are welcome — open a PR or file an issue.
